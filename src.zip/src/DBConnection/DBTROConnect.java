package DBConnection;

import java.sql.*;
/**
 *
 * @author SURYA DEVARAKONDA
 */
public class DBTROConnect {
    public ResultSet rs;
        public Statement st;
	public Connection conn;
		
        public void connect()
        {
            try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shravani","shravani02");
			st = conn.createStatement();
		}
		
		catch(Exception e)
		{
			System.out.println("Exception:  "+e);
		}
        }
        
        public boolean verifyLogin(String id,String pssw) throws SQLException
	{
			String q = "where id= '"+id+"' and password='"+pssw+"'";
			rs = st.executeQuery("select * from trologin "+q);
		
		
			if(rs.next())
                            return true;
			
			else 
                            return false;
	}
        
        public void fetchCounsellorData(String username)
        {
            try
            {
                rs = st.executeQuery("select tro_name,feedbacks_addressed from tro1 where tro_id='"+username+"'");
                rs.next();
            }
            catch (Exception e)
            {
                System.out.println(e);
            }
        }
        
        public void fetchTableData(String id)
        {
            try
            {
                String q = "select i.feedback_id,s.student_name,i.title,i.status,i.submission_time from student1 s inner join feedback1 i on s.student_id = i.student_id and s.tro_id='"+id+"'";    
                 rs = st.executeQuery(q);
            }
            catch (Exception e)
            {
                System.out.println(e);
            }
            
        }
        
        public void viewPendingStudentIssue(String id)
        {
            try
            {
                String q = "select i.feedback_id,s.student_name,i.title,i.feedback from feedback1 i inner join student1 s on i.student_id = s.student_id and i.feedback_id='"+id+"'";
                rs = st.executeQuery(q);
                rs.next();
            }
            catch (Exception e)
            {
                System.out.println(e);
            }
        }
        
        public void viewRespondedStudentIssue(String id)
        {
            try
            {
                rs = st.executeQuery("select suggestions from suggestive_measures1 where feedback_id='"+id+"'");
                rs.next();
            }
            
            catch (Exception e)
            {
                System.out.println(e);
            }
        }
        
        public void respondIssue(String id,String suggestions,String t_id)
        {
            try
            {
                String q = "update  feedback1 set status='Responded' where feedback_id='"+id+"'";
                st.executeQuery(q);
                 System.out.println("1");
                q = "update  suggestive_measures1 set suggestions='"+suggestions+"' where feedback_id='"+id+"'";
                st.executeQuery(q);
                System.out.println("2");
                
                
                q="update tro set feedbacks_addressed=feedbacks_addressed+1 where tro_id='"+t_id+"'";
                st.executeQuery(q);
                System.out.println("4");
            }
            
            catch(Exception e)
            {
                System.out.println("respond isue: "+e);
            }
        }
        
        public void getStatistics(String t_id)
        {
            try
            {
                String q = "select student_name,feedbacks_submitted from student1 where tro_id='"+t_id+"' order by 2 desc";
                rs = st.executeQuery(q);
            }
            
            catch(Exception e)
            {
                System.out.println("respond isue: "+e);
            }
            
        }
        
        public void updateResponse(String id,String sug)
        {
            try
            {
                String q = "update suggestive_measures1 set suggestions='"+sug+"' where feedback_id='"+id+"'";
                st.executeQuery(q);
                
            }
            
            catch(Exception e)
            {
                System.out.println(e);
            }
        }
        
        public void deleteResponse(String id,String username)
        {
            try
            {
                st.executeQuery("update suggestions set suggestions='None' where feedback_id='"+id+"'");
                st.executeQuery("update feedback1 set status='Pending' where feedback_id='"+id+"'");
                //st.executeQuery("update tro1 set feedbacks_addressed=feedbacks_addressed-1 where tro_id='"+username+"'");
            }
            
            catch(Exception e)
            {
                System.out.println(e);
            }
        }
        
        public void getStudentsList(String t_id)
        {
            try
            {
                rs = st.executeQuery("select student_id from student1 where tro_id='"+t_id+"'");
            }
            
            catch(Exception e)
            {
                System.out.println(e);
            }
        }
        
      /*  public void fetchspecificTableData(String s_id)
        {
            try
            {
                String q = "select i.feedback_id,s.student_name,i.title,submission_time from student1 s inner join feedback1 i on s.student_id = i.student_id and s.student_id='"+s_id+"'";
                rs = st.executeQuery(q);
            }
            
            catch(Exception e)
            {
                System.out.println("Exception "+e);
            }
        }*/
        
        public void fetchDateTableData(String date)
        {
            try
            {
                String q = "select i.feedback_id,s.student_name,i.title from student1 s inner join issues i on s.student_id = i.student_id and submission_time='"+date+"'";
                rs = st.executeQuery(q);
            }
            catch(Exception e)
            {
                System.out.println(e);
            }
        }
}
