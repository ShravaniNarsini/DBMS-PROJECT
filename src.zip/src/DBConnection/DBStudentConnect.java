package DBConnection;

import java.sql.*;
public class DBStudentConnect 
{
	public ResultSet rs;
        public Statement st;
	public Connection conn;
		
        public void connect()
        {
            try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shravani","shravani02");
			st = conn.createStatement();
		}
		
		catch(Exception e)
		{
			System.out.println("Exception:  "+e);
		}
        }
        
	public boolean verifyLogin(String id,String pssw) throws SQLException
	{
			String q = "where id= '"+id+"' and password='"+pssw+"'";
			rs = st.executeQuery("select * from studentlogin "+q);
		
		
			if(rs.next())
                            return true;
			
			else 
                            return false;
	}
	
        public void fetchStudentData(String username)
        {
            try
            {
                String query ="select student_name,tro_name,tro_phone from student1 s,tro1 t where s.tro_id = t.tro_id and s.student_id='"+username+"'";
                rs = st.executeQuery(query);
               /* System.out.println(query);
                int i=1;
                if(rs1.next()==false)
                    System.out.println("Empty");
                while(rs1.next())
                {
                    System.out.println(rs1.getString(i));
                    i++;
                }*/
               rs.next();
               
            }
            catch(Exception e)
            {
                System.out.println("Error DB connect:  "+e);
            }
        }
        
        public void fetchStudentTableData(String username)
        {
            try
            {
                String query = "select i.feedback_id,status from feedback1 i inner join suggestive_measures1 s on i.feedback_id=s.feedback_id and i.student_id = '"+username+"' order by 1";
                rs = st.executeQuery(query);
            }
            catch (Exception e)
            {
                System.out.println("Fetch Student table error: "+e);
            }
        }
        
        public void addIssue(String username,String title,String feedback,String date)
        {
            try
            {
                rs = st.executeQuery("select count(*) from feedback1 where student_id = '"+username+"'");
                
                rs.next();
                
                String id = "";
                int i = 5;
                
                while(i<username.length())
                {
                    if(username.charAt(i)!='-')
                        id+=username.charAt(i);
                    i++;
                }
                
                id = id + (rs.getInt(1)+1)+"";
                
                rs = st.executeQuery("select tro_id from student1 where student_id='"+username+"'");
                rs.next();
                
                String t_id = rs.getString(1);
                System.out.println(rs.getString(1));
                
                String q = "('"+id+"','"+username+"','"+t_id+"','"+feedback+"','Pending','"+date+"','"+title+"')";
                
                st.executeQuery("insert into feedback1 values"+q);
                
                q = "('"+id+"','"+username+"','"+t_id+"','None')";
                st.executeQuery("insert into suggestive_measures1 values"+q);
                
               
                q="update student1 set feedbacks_submitted=feedbacks_submitted+1 where student_id='"+username+"'";
                st.executeQuery(q);
            }
            catch(Exception e)
                 {
                        System.out.println(e);
                }
            
        }
        public void deleteStudentIssue(String id,String username)
        {
                try
                {
                    st.executeQuery("delete feedback1 where feedback_id='"+id+"'");
                    st.executeQuery("delete suggestive_measures1 where feedback_id='"+id+"'");
                    
                    st.executeQuery("update student1 set feedbacks_submitted = feedbacks_submitted-1 where student_id='"+username+"'");
                }
                catch(Exception e)
                {
                    System.out.println(e);
                }
        
        }
        
        public void viewStudentIssue(String id)
        {
            try
            {
                rs = st.executeQuery("select i.feedback_id,title,feedback,suggestions,status from feedback1 i inner join suggestive_measures1 s on i.feedback_id=s.feedback_id where i.feedback_id='"+id+"'");
                rs.next();
            }
                catch(Exception e)
                {
                    System.out.println(e);
                }
        }
        
        public void updateStudentIssue(String id,String title,String desc,String time)
        {
            try
            {
                st.executeQuery("update feedback1 set feedback='"+desc+"', status='Pending',submission_time='"+time+"', title='"+title+"' where feedback_id='"+id+"'");
                
            }
            
            catch(Exception e)
            {
                    System.out.println(e);
                }
        }
       
}
